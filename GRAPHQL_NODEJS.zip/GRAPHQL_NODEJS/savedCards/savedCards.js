import { ApolloServer,gql } from 'apollo-server';
import { savedcardsAPI } from './savedCardsAPI.js';

const typeDefs = gql`
    type Query{
        savedcards(cardDetails: savedcardsInput): savedcardsResponse
    }

  input savedcardsInput {
    acudID: String
  }

  type savedcardsResponse{
    message:String
    status: Boolean
  }
`;

const resolvers = {
    Query: {
        savedcards(userApp, payLoad) {
          return new savedcardsAPI().message(payLoad); //users:()=>users
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(8005).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

