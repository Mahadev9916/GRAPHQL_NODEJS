import { ApolloServer,gql } from 'apollo-server';
import { newAdminAPI } from './newAdminAPI.js';

const typeDefs = gql`
    type Query{
        NewAdmin : NewAdminResponse
    }

  type NewAdminResponse{
            title: String
            Image: String
        
  }
`;

const resolvers = {
    Query: {
        NewAdmin(cityApp, payLoad) {
            return new newAdminAPI().NewAdmin(payLoad);
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(9001).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

