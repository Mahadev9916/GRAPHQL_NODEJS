import { RESTDataSource } from "apollo-datasource-rest";

class NewAdminAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:https://tengagecep.trinityiot.in/CitizenPortal-ETC/en/rest/v1/';
        this.initialize({});
    }

    async NewAdmin(payload) {
        const uri = "NewAdministrativeCapital?_format=hal_json"
        return this.get(uri, payload).then((params) => {
            return params;
        });
    }
}
export const newAdminAPI = NewAdminAPI;