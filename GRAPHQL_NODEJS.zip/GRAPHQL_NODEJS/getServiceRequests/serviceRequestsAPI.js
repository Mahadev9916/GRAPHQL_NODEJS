import { RESTDataSource } from "apollo-datasource-rest";

class serviceRequestsAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:8080/CEPMobileService/';
        this.initialize({});
    }

    async apiRepsonse(payload) {
        const uri = "meter/serviceRequests"
        return this.post(uri, payload.servicerequests).then((params) => {
            return params;
        });
    }
}
export const servicerequestsAPI = serviceRequestsAPI;