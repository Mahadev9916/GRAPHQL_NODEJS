import { ApolloServer,gql } from 'apollo-server';
import { servicerequestsAPI } from './serviceRequestsAPI.js';


const typeDefs = gql`
    type Query{
        servicerequests(requests: servicerequestsInput): servicerequestsResponce
    }
  input servicerequestsInput {
    userId: String
    tenantId: Int
    offset: Int
    size: Int
    statusID: Int
  }

  type servicerequestsResponce{
    apiRepsonse: APIRepsonse
    status: Boolean
    statusCode: Int
  }
type APIRepsonse{
    result: [resultResponse]
    status: Boolean
}
  type resultResponse {
    grievance_id: String
    request_type: String
    transaction_sop_id: Int
    payment_status: Int
    received_time: String
    company_code: String
    request_type_id: Int
    status: String
}
`;

const resolvers = {
    Query: {
        servicerequests(userApp, payLoad) {
          return new servicerequestsAPI().apiRepsonse(payLoad); 
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(8004).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

