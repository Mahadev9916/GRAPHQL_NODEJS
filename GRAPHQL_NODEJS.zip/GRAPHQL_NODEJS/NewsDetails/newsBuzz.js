import { ApolloServer,gql } from 'apollo-server';
import { newsBuzzAPI } from './newsBuzzAPI.js';



const typeDefs = gql`
    type Query{
        newsBuzz: newsBuzzResponse
    }

  type newsBuzzResponse{
    title:String
    created:String
    description:String
    id:String
    image:String
    category:String
    totalviews:String
    todayviews:String
    category_id:String
    field_news_inner_page_image:String
    field_minutes_to_read:String
  }
`;

const resolvers = {
    Query: {
        newsBuzz(userApp, payLoad) {
          return new newsBuzzAPI().newsBuzz(payLoad); 
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(9003).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

