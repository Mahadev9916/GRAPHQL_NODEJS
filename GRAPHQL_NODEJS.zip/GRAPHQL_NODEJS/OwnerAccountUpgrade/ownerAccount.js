import { ApolloServer,gql } from 'apollo-server';
import {owneraccountAPI} from './ownerAccountAPI.js';

const typeDefs = gql`
    type Query{
        ownerAccountUpgrade(accountDetails: ownerAccountInput): ownerAccountResponse
    }



  input ownerAccountInput {
    userId: String
    compoundName: String
    streetName: String
    floorNumber: String
    unitNumber: String
    unitName: String
    postalCode: String
    buildingNumber: String
    city: String
    latitude: Float
    longitude: Float
    area: String
    remarks: String
    sourceTypeId: Int
    typeOfRequest: Int
    tenantId: Int
    files: [filesResponse]
  }

 input  filesResponse {
    fileLocalPath: String
    fileLocalPathToDisplay:String
    isFileAttached: Boolean
    fileType: String
    fileTypeId: Int
    fileUploadedUrl: String
  }

  type ownerAccountResponse{
    apiRepsonse:APIRepsonse
    status:Boolean
    statusCode:Int
  }
  type APIRepsonse{
    message:String
    status:Boolean
    }
`;

const resolvers = {
    Query: {
        ownerAccountUpgrade(userApp, payLoad) {
          return new owneraccountAPI().apiRepsonse(payLoad); 
      }   
    }
};

const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(8003).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});