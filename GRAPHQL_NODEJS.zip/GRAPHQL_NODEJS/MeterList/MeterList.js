import { ApolloServer,gql } from 'apollo-server';
import {meterlistAPI}  from  "./MeterListAPI.js";



const typeDefs = gql`
    type Query{
        MeterListDetails(meterDetails: MeterListDetailsInput): MeterListDetailsResponse
    }

  input MeterListDetailsInput {
        companyCode:String
        acudId:String
        unitId:String
  }

  type MeterListDetailsResponse{
    apiRepsonse: APIResponse
    status: Boolean
    statusCode: Int
}

type APIResponse {
    success: Boolean
    message: String
    meterCount: [meterCountResponse]
}

type meterCountResponse{
    meterCategory: String
      count: Int
}
`;

const resolvers = {
    Query: {
        MeterListDetails(userApp, payLoad) {
          return new meterlistAPI().apiRepsonse(payLoad); 
      }   
    },
};


    const server = new ApolloServer({
        typeDefs, resolvers 
 
    });

    server.listen(8002).then(({ url }) => {
        console.log(`🚀 Server ready at ${url}`);
    });

