import { RESTDataSource } from "apollo-datasource-rest";

class MeterListAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:8080/CEPMobileService/';
        this.initialize({});
    }

    async apiRepsonse(payload) {
        const uri = "meter/meterList"
        return this.post(uri, payload.meterDetails).then((params) => {
            return params;
        });
    }
}
export const meterlistAPI = MeterListAPI;