import { ApolloServer,gql } from 'apollo-server';
import { faqAPI } from './faqAPI.js';

const typeDefs = gql`
    type Query{
        faq : faqResponse
    }

  type faqResponse{
            question: String
            answer: String
  }
`;

const resolvers = {
    Query: {
        faq(cityApp, payLoad) {
            return new faqAPI().faq(payLoad);
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(9002).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

