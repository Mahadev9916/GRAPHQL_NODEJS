import { RESTDataSource } from "apollo-datasource-rest";

class FaqAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'https://tengagecep.trinityiot.in/v-ETC/en/';
        this.initialize({});
    }

    async faq(payload) {
        const uri = "faqAPI?_format=hal_json"
        return this.get(uri, payload).then((params) => {
            return params;
        });
    }
}
export const faqAPI = FaqAPI;