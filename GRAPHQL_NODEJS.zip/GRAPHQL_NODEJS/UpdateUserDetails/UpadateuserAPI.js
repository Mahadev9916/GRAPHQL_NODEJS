import { RESTDataSource } from "apollo-datasource-rest";

class UpadateuserAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:8080/CEPMobileService/';
        this.initialize({});
    }

    async message(payload) {
        const uri = "user/updateUserDetails"
        return this.post(uri, payload).then((params) => {
            return params;
        });
    }
}
export const upadateuserAPI = UpadateuserAPI;