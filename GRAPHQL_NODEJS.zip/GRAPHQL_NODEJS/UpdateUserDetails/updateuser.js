import { ApolloServer,gql } from 'apollo-server';
import { upadateuserAPI } from './UpadateuserAPI.js';

// const{ ApolloServer } =require( 'apollo-server');
// const UpadateuserAPI =require('./UpadateuserAPI.js');

const typeDefs = gql`
    type Query{
        updateUserDetails(userDetails: updateUserDetailsInput): updateUserDetailsResponse
    }



  input updateUserDetailsInput {
    mobileNumber: String
    webportal_fcm_id: String
    fcmId: String
  }

  type updateUserDetailsResponse{
        message: String
        userId:String
        status: Boolean
  }
`;

const resolvers = {
    Query: {
        updateUserDetails(userApp, payLoad) {
          return new upadateuserAPI().message(payLoad); //users:()=>users
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(8006).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

