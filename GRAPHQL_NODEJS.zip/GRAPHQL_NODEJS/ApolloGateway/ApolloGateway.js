import { ApolloServer,gql } from 'apollo-server';
import { ApolloGateway} from '@apollo/gateway';

const gateway = new ApolloGateway({
    serviceList: [
        { name: 'viewGrievance', url: 'http://localhost:8001' },
        { name: 'MeterList', url: 'http://localhost:8002' },
        { name: 'ownerAccountUpgrade', url: 'http://localhost:8003' },
        { name: 'servicerequests', url: 'http://localhost:8004' },
        { name: 'savedcards', url: 'http://localhost:8005' },
        { name: 'updateUserDetails', url: 'http://localhost:8006' },
    ],
   
});

let server1= new ApolloServer({
    gateway,
    subscriptions: false,
    cors: {
        "Access-Control-Allow-Origin": "*"
    }
});
server1.listen(1334).then((url) => {
    console.log(url);
})