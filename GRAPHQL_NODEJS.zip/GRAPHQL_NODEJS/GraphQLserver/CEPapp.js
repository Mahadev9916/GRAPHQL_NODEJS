import { ApolloServer, gql } from 'apollo-server';
import { CEPappAPIServices } from './CEPappAPI.js';
import { buildFederatedSchema } from '@apollo/federation';

const typeDefs = gql`

type Query {

  MeterListDetails(meterDetails: MeterListDetailsInput): MeterListDetailsResponse,
  servicerequests(requests: servicerequestsInput): servicerequestsResponce,
  newsBuzz: newsBuzzResponse,
  ownerAccountUpgrade(accountDetails: ownerAccountInput): ownerAccountResponse,
  savedcards(cardDetails: savedcardsInput): savedcardsResponse,
  updateUserDetails(userDetails: updateUserDetailsInput): updateUserDetailsResponse,
  viewGrievance(ViewGrievance: viewGrievanceInput): viewGrievanceResponse,

}
input MeterListDetailsInput {
    companyCode:String
    acudId:String
    unitId:String
}
input servicerequestsInput {
    userId: String
    tenantId: Int
    offset: Int
    size: Int
    statusID: Int
  }
  input ownerAccountInput {
    userId: String
    compoundName: String
    streetName: String
    floorNumber: String
    unitNumber: String
    unitName: String
    postalCode: String
    buildingNumber: String
    city: String
    latitude: Float
    longitude: Float
    area: String
    remarks: String
    sourceTypeId: Int
    typeOfRequest: Int
    tenantId: Int
    files: [filesResponse]
  }

 input  filesResponse {
    fileLocalPath: String
    fileLocalPathToDisplay:String
    isFileAttached: Boolean
    fileType: String
    fileTypeId: Int
    fileUploadedUrl: String
  }
  input savedcardsInput {
    acudID: String
  }
  input updateUserDetailsInput {
    mobileNumber: String
    webportal_fcm_id: String
    fcmId: String
  }
  input viewGrievanceInput {
    emailId: String
    isGrivanceRequest: String
  }



type MeterListDetailsResponse{
apiRepsonse: APIResponse
status: Boolean
statusCode: Int
}
type APIResponse {
success: Boolean
message: String
meterCount: [meterCountResponse]
}

type meterCountResponse{
meterCategory: String
  count: Int
}
type servicerequestsResponce{
    apiRepsonse: APIRepsonse2
    status: Boolean
    statusCode: Int
  }
type APIRepsonse2{
    result: [resultResponse]
    status: Boolean
}
  type resultResponse {
    grievance_id: String
    request_type: String
    transaction_sop_id: Int
    payment_status: Int
    received_time: String
    company_code: String
    request_type_id: Int
    status: String
}
type newsBuzzResponse{
    title:String
    created:String
    description:String
    id:String
    image:String
    category:String
    totalviews:String
    todayviews:String
    category_id:String
    field_news_inner_page_image:String
    field_minutes_to_read:String
  }
  type ownerAccountResponse{
    apiRepsonse:APiRepsonse
    status:Boolean
    statusCode:Int
  }
  type APiRepsonse{
    message:String
    status:Boolean
    }
 type savedcardsResponse{
        message:String
        status: Boolean
      }
 type updateUserDetailsResponse{
        message: String
        userId:String
        status: Boolean
  }
  type viewGrievanceResponse{
    apiRepsonse:APIRepsonse 
    status: Boolean
    statusCode: Int
}
type APIRepsonse{
    ResultData: [ResultDataResponse]
    status: Boolean
}

type ResultDataResponse {
    updated_time: String
    incident_type: String
    user_remarks: String
    card_product_id: String
    is_grievance_linked: String
    bank: String
    status_id: Int
    bank_id: String
    cardAcud: String
    grievance_sub_type_id: Int
    status_new: String
    longitude: Float
    meter_type_id: String
    gener: String
    otp: String
    home_address_city: String
    nationality: String
    dob: String
    name: String
    card_gender_id: String
    phone_number: String
    grievance_type_id: Int
    request_type_id: Int
    is_card_request: String
    to_agent: Int
    citizen_type_name: String
    agent_remarks: String
    status: String
    tenant_id: Int
    national_id: String
    attachments: [attachmentsResponse],
    request_type: String
    latitude: Float
    card_product_name: String
    received_time: String
    citizen_type_id: String
    incident_sub_type: String
    is_duplicate:String
    linked_grievance_id: String
    connection_name: String
    grievance_id: String
    city_name: String
    home_address_phone_number: String
    country_of_birth: String
    home_address_postal_code: String
    country_name: String
    first_name:String
    email: String
    address: String
    payment_type_name: String
    last_name:String
    card_national_id:String
    status_id_new: Int
    gender_id: Int
    home_address_2:String
    home_address_1: String
    is_anonymous: String
    id_expary_date:String
    city_of_birth: String
}

type  attachmentsResponse{
    attachment_id: Int
    file_url: String
    grievance_id: String
    file_type_id: Int
}
`;


const resolvers = {
    Query: {
    
    MeterListDetails(userApp, payLoad) {
        return new CEPappAPIServices().MeterList(payLoad); 
    },
    servicerequests(userApp, payLoad) {
        return new CEPappAPIServices().service(payLoad); 
    } ,
    newsBuzz(userApp, payLoad) {
        return new CEPappAPIServices().newsbuzz(payLoad); 
    } ,
    ownerAccountUpgrade(userApp, payLoad) {
        return new CEPappAPIServices().ownerAccount(payLoad); 
    },

    savedcards(userApp, payLoad) {
        return new CEPappAPIServices().cards(payLoad); 
    },
    updateUserDetails(userApp, payLoad) {
        return new CEPappAPIServices().updateUser(payLoad); 
    } ,
    viewGrievance(userApp, payLoad) {
        return new CEPappAPIServices().Grievance(payLoad); 
    }        
     
    },
};

export const CepAppService = (port)=>{
  const server = new ApolloServer({
    schema: buildFederatedSchema(
      {typeDefs, resolvers}
    ),
    cors: {
      "Access-Control-Allow-Origin": "*"
  }
  });

server.listen(port).then(({ url }) => {
    console.log(` Server ready at ${url}`);
});
}