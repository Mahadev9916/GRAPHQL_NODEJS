import { ApolloServer } from 'apollo-server';
import{ ApolloGateway } from '@apollo/gateway';
import { CMSAppService} from './cmsApp.js'
import { CepAppService } from "./CEPapp.js";

CMSAppService(8888);
CepAppService(9999);

const gateway = new ApolloGateway({
    serviceList: [
        { name: 'CEPapp', url: 'http://localhost:9999' },
        { name: 'cmsapp', url: 'http://localhost:8888' },
    ]  
});

let server1= new ApolloServer({
    gateway:gateway,
    subscriptions: false
});

setTimeout(() => {
    server1.listen(1334).then((url) => {
        console.log(url);
    })
}, 1000);

