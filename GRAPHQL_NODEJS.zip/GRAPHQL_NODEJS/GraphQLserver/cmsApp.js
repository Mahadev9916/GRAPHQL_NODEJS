import { buildFederatedSchema } from '@apollo/federation';
import { ApolloServer, gql } from 'apollo-server';
import {cmsAppAPI} from './CmsAppAPI.js';


const typeDefs = gql`

type Query {
  faq: [faqReponse],
  NewAdmin : NewAdminResponse,
}

type faqReponse{
  question: String
  answer: String
}

type NewAdminResponse{
  title: String
  Image: String

}
`;


const resolvers = {
    Query: {
      faq(cmsApp, payLoad) {
          return new cmsAppAPI().faq(payLoad);
      },
      NewAdmin(cityApp, payLoad) {
        return new cmsAppAPI().NewAdmin(payLoad);
  }   
     
   },
};



export const CMSAppService = (port)=>{
  const server = new ApolloServer({
    schema: buildFederatedSchema(
      {typeDefs, resolvers}
    )
  });
  
  server.listen(port).then(({ url }) => {
    console.log(` Server ready at ${url}`);
  });
}