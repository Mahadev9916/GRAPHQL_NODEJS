import { RESTDataSource } from "apollo-datasource-rest";
class CmsAppAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'https://tengagecep.trinityiot.in/CitizenPortal-ETC/';
        this.initialize({});
    }

    async faq(payload) {
        const url = "en/faqAPI?_format=hal_json"
        return this.get(url,payload).then((params) => {
            return params;
        });
    }  
    
    async NewAdmin(payload) {
        const uri = "NewAdministrativeCapital?_format=hal_json"
        return this.get(uri, payload).then((params) => {
            return params;
        });
    }

}


export const cmsAppAPI = CmsAppAPI;

