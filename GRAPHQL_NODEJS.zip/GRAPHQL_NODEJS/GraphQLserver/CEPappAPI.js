import { RESTDataSource } from "apollo-datasource-rest";


class CEPappAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:8080/CEPMobileService/';
        this.initialize({});
    }

    async MeterList(payload) {
        const uri = "meter/meterList"
        return this.post(uri, payload.meterDetails).then((params) => {
            return params;
        });
    }
   
    async service(payload) {
        const uri = "meter/serviceRequests"
        return this.post(uri, payload.requests).then((params) => {
            return params;
        });
    }

    async newsbuzz(payload) {
        const uri = "cms/news-buzz"
        return this.get(uri, payload).then((params) => {
            return params;
        });
    }
  
    async ownerAccount(payload) {
        const uri = "account/owner"
        return this.post(uri, payload.accountDetails).then((params) => {
            return params;
        });
    }
  
    
    async cards(payload) {
        const uri = "payment/savedCards"
        return this.post(uri, payload.cardDetails).then((params) => {
            return params;
        });
    }
 
    async updateUser(payload) {
        const uri = "user/updateUserDetails"
        return this.post(uri, payload.userDetails).then((params) => {
            return params;
        });
    }

    async Grievance (payload) {
        const uri = "report/viewGrievance"
        return this.post(uri, payload.ViewGrievance).then((params) => {
            return params;
        });
    }

}

export const CEPappAPIServices = CEPappAPI;
