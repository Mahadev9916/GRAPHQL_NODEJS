import { ApolloServer,gql } from 'apollo-server';
import { viewgrievanceAPI } from './viewGrievanceAPI.js';


const typeDefs = gql`
    type Query{
        viewGrievance(ViewGrievance: viewGrievanceInput): viewGrievanceResponse
    }



  input viewGrievanceInput {
    emailId: String
    isGrivanceRequest: String
  }

  type viewGrievanceResponse{
    apiRepsonse:APIRepsonse 
    status: Boolean
    statusCode: Int
}
type APIRepsonse{
    ResultData: [ResultDataResponse]
    status: Boolean
}

type ResultDataResponse {
    updated_time: String
    incident_type: String
    user_remarks: String
    card_product_id: String
    is_grievance_linked: String
    bank: String
    status_id: Int
    bank_id: String
    cardAcud: String
    grievance_sub_type_id: Int
    status_new: String
    longitude: Float
    meter_type_id: String
    gener: String
    otp: String
    home_address_city: String
    nationality: String
    dob: String
    name: String
    card_gender_id: String
    phone_number: String
    grievance_type_id: Int
    request_type_id: Int
    is_card_request: String
    to_agent: Int
    citizen_type_name: String
    agent_remarks: String
    status: String
    tenant_id: Int
    national_id: String
    attachments: [attachmentsResponse],
    request_type: String
    latitude: Float
    card_product_name: String
    received_time: String
    citizen_type_id: String
    incident_sub_type: String
    is_duplicate:String
    linked_grievance_id: String
    connection_name: String
    grievance_id: String
    city_name: String
    home_address_phone_number: String
    country_of_birth: String
    home_address_postal_code: String
    country_name: String
    first_name:String
    email: String
    address: String
    payment_type_name: String
    last_name:String
    card_national_id:String
    status_id_new: Int
    gender_id: Int
    home_address_2:String
    home_address_1: String
    is_anonymous: String
    id_expary_date:String
    city_of_birth: String
}

type  attachmentsResponse{
    attachment_id: Int
    file_url: String
    grievance_id: String
    file_type_id: Int
}

`;

const resolvers = {
    Query: {
        viewGrievance(userApp, payLoad) {
          return new viewgrievanceAPI().apiRepsonse(payLoad); 
      }   
    }
};


const server = new ApolloServer({
    typeDefs, resolvers 
  
});

server.listen(8001).then(({ url }) => {
    console.log(`🚀 Server ready at ${url}`);
});

