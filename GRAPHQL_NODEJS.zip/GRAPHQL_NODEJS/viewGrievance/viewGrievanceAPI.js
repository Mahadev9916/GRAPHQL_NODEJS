import { RESTDataSource } from "apollo-datasource-rest";

class viewGrievanceAPI extends RESTDataSource {
    constructor() {
        super();
        this.baseURL = 'http://192.168.1.52:8080/CEPMobileService/';
        this.initialize({});
    }

    async apiRepsonse (payload) {
        const uri = "report/viewGrievance"
        return this.post(uri, payload).then((params) => {
            return params;
        });
    }
}
export const viewgrievanceAPI = viewGrievanceAPI;